# AmneziaWG Multi-Profile (Root & App Routing)

Системный клиент AmneziaWG (AWG) для Android с поддержкой одновременной работы нескольких туннелей, раздельной маршрутизацией приложений (Per-App Split Tunneling), защитой от пересечения маршрутов и полной поддержкой протокола обфускации AWG (включая сигнатуры I1-I5).

---

## 1. Возможности

- **Мульти-профили (Multi-Profile Concurrent Tunnels):** Одновременный запуск нескольких независимых туннелей AmneziaWG (например, `awg0` для WARP, `awg1` для рабочего VPN, `awg2` для зарубежных сервисов).
- **Раздельная маршрутизация приложений (Per-App Split Tunneling):** Назначение индивидуального списка Android-приложений (по именам пакетов и системным UIDs) на каждый профиль.
- **Строгая изоляция маршрутов (Strict Route Non-Intersection):** Встроенный детектор и арбитр коллизий гарантирует отсутствие конфликтов и утечек маршрутов между профилями.
- **Поддержка всех параметров обфускации AmneziaWG:**
  - `Jc`, `Jmin`, `Jmax` (Junk packet count & size range)
  - `S1`, `S2`, `S3`, `S4` (Init/Response packet junk payloads)
  - `H1`, `H2`, `H3`, `H4` (Magic packet headers)
  - `I1`, `I2`, `I3`, `I4`, `I5` (Custom Protocol Signature packets: `<b 0x...>`, `<r N>`, `<t>`, `<c>`)
- **DNS-защита:** Перенаправление DNS-запросов изолированных приложений в туннель профиля для предотвращения DNS-утечек.
- **KillSwitch:** Опциональная блокировка прямого выхода в сеть при падении туннеля для защищенных приложений.
- **Сетевой страж (Wi-Fi/LTE Handover):** Автоматическое обновление шлюзов и маршрутов при переключении между Wi-Fi и мобильной связью без разрыва соединений.
- **Современный WebUI:** Панель управления на базе Material 3 Expressive, встроенная прямо в интерфейс KernelSU / APatch / Magisk.
- **Action Button:** Быстрое управление и перезапуск через физическую/экранную кнопку менеджера.

---

## 2. Структура каталогов и профилей

Все пользовательские профили хранятся в защищенном каталоге `/data/adb/amneziawg/profiles/`:

- `profile_name.conf` — стандартная конфигурация WireGuard / AmneziaWG (секции `[Interface]` и `[Peer]`).
- `profile_name.json` — параметры маршрутизации и изоляции:
  - `enabled` (boolean): Автозапуск при загрузке системы.
  - `interface` (string): Имя сетевого интерфейса (например, `awg0`, `awg1`).
  - `table` (number): Номер таблицы Linux Policy Routing (по умолчанию `201..299`).
  - `priority` (number): Приоритет правила `ip rule` (по умолчанию `10201..10299`).
  - `routing_mode` (string): `include_apps` (только выбранные), `exclude_apps` (все кроме выбранных), `all_traffic` (весь трафик).
  - `apps` (array of strings): Список пакетов приложений (например, `["org.telegram.messenger", "com.google.android.youtube"]`).
  - `dns` (string): Адрес DNS-сервера (например, `1.1.1.1, 1.0.0.1`).
  - `killswitch` (boolean): Включение защиты от утечек при обрыве туннеля.

---

## 3. Управление через CLI

Модуль предоставляет консольную утилиту `awg-controller`:

```sh
# Запуск всех включенных профилей
awg-controller start all

# Запуск конкретного профиля
awg-controller start work_vpn

# Остановка всех профилей и полная очистка правил
awg-controller stop all

# Остановка конкретного профиля
awg-controller stop work_vpn

# Перезапуск профилей
awg-controller restart all

# Проверка текущего статуса активных туннелей
awg-controller status

# Статус в формате JSON (для скриптов и WebUI)
awg-controller status json

# Проверка конфликтов и пересечений маршрутов
awg-controller check-conflicts

# Синхронизация правил при установке/обновлении приложений
awg-controller sync-rules
```

---

## 4. Совместимость

- **Менеджеры Root:** Magisk v24+, KernelSU v0.6+, KernelSU Next, APatch v0.10+.
- **Версии Android:** Android 9, 10, 11, 12, 13, 14, 15, 16+.
- **Архитектуры процессора:** `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64`.
