---

---

## Донаты и поддержка / Donations
Ваша поддержка помогает развивать и поддерживать проекты! / Your support helps keep these projects active!

- СБП: `+7 923 618-89-93`
- Т-Банк: [Перевод Т-Банк](https://www.tinkoff.ru/rm/r_qoRUrMgqrw.gQAquXjKzF/ca7Vm7131)
- Ю.Money (Яндекс): [Перевод Ю.Money](https://yoomoney.ru/to/410011494875904)
- Crypto: [USDT | GRAM (Telegram Crypto Bot)](http://t.me/send?start=IVjCT8LiszJ2)
- TON Wallet (USDT): `UQCLyovMu5882XPekfUqXOLFbYFHROaB9uoWMsIaifvMqEC4`

---

## Лицензия / License

Модуль распространяется бесплатно под лицензией MIT. При распространении сохранение авторства **eCubz** и ссылки на канал **https://t.me/module_ecubz** обязательно.
