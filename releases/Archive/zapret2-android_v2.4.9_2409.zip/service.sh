#!/system/bin/sh
# Zapret2 eCubz service control script
# Author: eCubz (https://t.me/eCubz) | Telegram: https://t.me/module_ecubz

MODDIR="${0%/*}"
CONF_FILE="$MODDIR/zapret2.conf"
APPS_LIST="$MODDIR/apps.list"
EXCLUDE_LIST="$MODDIR/exclude.list"
AUTO_DOMAINS_FILE="$MODDIR/auto_domains.list"
EXCLUDE_DOMAINS_FILE="$MODDIR/exclude_domains.list"
FORCE_TCP_APPS_LIST="$MODDIR/force_tcp_apps.list"
RUN_DIR="$MODDIR/run"
NFQWS_PID_FILE="$RUN_DIR/nfqws2.pid"
WATCHER_PID_FILE="$RUN_DIR/inotifyd.pid"
SERVICE_LOCK="$RUN_DIR/service.lock"
LOG_DIR="/sdcard/eCubz"
LOG_FILE="$LOG_DIR/zapret2_debug.log"

BIN_DIR=""
for path in "$MODDIR/system/bin" "$MODDIR/binaries/android-arm64" "$MODDIR/binaries/android-arm" "$MODDIR/binaries/android-x86_64" "$MODDIR/binaries/android-x86"; do
  if [ -x "$path/nfqws2" ]; then
    BIN_DIR="$path"
    break
  fi
done

if [ -z "$BIN_DIR" ]; then
  abi=$(getprop ro.product.cpu.abi 2>/dev/null)
  case "$abi" in
    arm64*) target_dir="$MODDIR/binaries/android-arm64" ;;
    x86_64*) target_dir="$MODDIR/binaries/android-x86_64" ;;
    x86*) target_dir="$MODDIR/binaries/android-x86" ;;
    *) target_dir="$MODDIR/binaries/android-arm" ;;
  esac
  if [ -f "$target_dir/nfqws2" ]; then
    BIN_DIR="$target_dir"
    chmod 755 "$BIN_DIR/nfqws2" 2>/dev/null
  fi
fi

[ -z "$BIN_DIR" ] && BIN_DIR="$MODDIR/system/bin"

mkdir -p "$LOG_DIR" "$RUN_DIR" 2>/dev/null
log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

setup_ip_forward_bind_mount() {
  local target="/proc/sys/net/ipv4/ip_forward"
  local stub_dir="/dev/ip_forward_stub"
  [ -f "$target" ] || return 0
  echo 1 > "$target" 2>/dev/null
  if grep -q "$stub_dir" /proc/mounts 2>/dev/null; then
    return 0
  fi
  mkdir -p "$stub_dir" 2>/dev/null
  echo "1" > "$stub_dir/ip_forward" 2>/dev/null
  chmod 644 "$stub_dir/ip_forward" 2>/dev/null
  mount -o bind "$stub_dir/ip_forward" "$target" 2>/dev/null
  log "Установлен bind-mount для $target"
}

cleanup_ip_forward_bind_mount() {
  local target="/proc/sys/net/ipv4/ip_forward"
  if grep -q "/dev/ip_forward_stub" /proc/mounts 2>/dev/null; then
    umount -l "$target" 2>/dev/null
    log "Снят bind-mount для $target"
  fi
}

stop_pid() {
  local pid_file="$1" name="$2" pid
  [ -f "$pid_file" ] || return 0
  pid=$(cat "$pid_file" 2>/dev/null)
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    kill -TERM "$pid" 2>/dev/null
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
    log "Остановлен процесс $name (PID $pid)"
  fi
  rm -f "$pid_file"
}

stop_owned_nfqws() {
  local proc pid cwd
  for proc in /proc/[0-9]*; do
    [ "$(cat "$proc/comm" 2>/dev/null)" = "nfqws2" ] || continue
    cwd=$(readlink "$proc/cwd" 2>/dev/null)
    [ "$cwd" = "$BIN_DIR" ] || continue
    pid=${proc##*/}
    kill -TERM "$pid" 2>/dev/null
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
  done
}

cleanup_iptables() {
  while iptables -w 5 -t mangle -D OUTPUT -j ZAPRET2_MANGLE 2>/dev/null; do :; done
  iptables -w 5 -t mangle -F ZAPRET2_MANGLE 2>/dev/null
  iptables -w 5 -t mangle -X ZAPRET2_MANGLE 2>/dev/null

  while iptables -w 5 -t mangle -D FORWARD -j ZAPRET2_MANGLE_FORWARD 2>/dev/null; do :; done
  iptables -w 5 -t mangle -F ZAPRET2_MANGLE_FORWARD 2>/dev/null
  iptables -w 5 -t mangle -X ZAPRET2_MANGLE_FORWARD 2>/dev/null

  while iptables -w 5 -t nat -D PREROUTING -j ZAPRET2_NAT_PREROUTING 2>/dev/null; do :; done
  iptables -w 5 -t nat -F ZAPRET2_NAT_PREROUTING 2>/dev/null
  iptables -w 5 -t nat -X ZAPRET2_NAT_PREROUTING 2>/dev/null

  while iptables -w 5 -t filter -D OUTPUT -j ZAPRET2_FILTER 2>/dev/null; do :; done
  iptables -w 5 -t filter -F ZAPRET2_FILTER 2>/dev/null
  iptables -w 5 -t filter -X ZAPRET2_FILTER 2>/dev/null

  while ip6tables -w 5 -t mangle -D OUTPUT -j ZAPRET2_MANGLE 2>/dev/null; do :; done
  while ip6tables -w 5 -t mangle -D FORWARD -j ZAPRET2_MANGLE_FORWARD 2>/dev/null; do :; done
  ip6tables -w 5 -t mangle -F ZAPRET2_MANGLE 2>/dev/null
  ip6tables -w 5 -t mangle -X ZAPRET2_MANGLE 2>/dev/null
  ip6tables -w 5 -t mangle -F ZAPRET2_MANGLE_FORWARD 2>/dev/null
  ip6tables -w 5 -t mangle -X ZAPRET2_MANGLE_FORWARD 2>/dev/null

  while ip6tables -w 5 -t filter -D OUTPUT -j ZAPRET2_FILTER 2>/dev/null; do :; done
  ip6tables -w 5 -t filter -F ZAPRET2_FILTER 2>/dev/null
  ip6tables -w 5 -t filter -X ZAPRET2_FILTER 2>/dev/null
}

load_package_uids() {
  local cache_file="$RUN_DIR/pkg_uids.cache"
  if [ -s "$cache_file" ]; then
    PACKAGE_UIDS=$(cat "$cache_file" 2>/dev/null)
  fi
  if [ -z "$PACKAGE_UIDS" ]; then
    PACKAGE_UIDS=$(pm list packages -U 2>/dev/null)
    [ -n "$PACKAGE_UIDS" ] && echo "$PACKAGE_UIDS" > "$cache_file" 2>/dev/null
  fi
}

get_app_uids() {
  local target_list="$1" app uid uids=""
  [ -f "$target_list" ] || return 0
  load_package_uids
  while read -r app || [ -n "$app" ]; do
    app=$(echo "$app" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
    case "$app" in \#*|'') continue ;; esac
    uid=$(printf '%s\n' "$PACKAGE_UIDS" | grep -F "package:$app uid:" | sed -n 's/.*uid:\([0-9]*\).*/\1/p' | head -n1)
    [ -n "$uid" ] && uids="$uids $uid"
  done < "$target_list"
  echo "$uids"
}

if [ "$1" != "reload" ]; then
  until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
  sleep 2
fi
[ -f "$CONF_FILE" ] && . "$CONF_FILE"
: "${MODE:=EXCLUDE}" "${STRATEGY_MODE:=SIMPLE}" "${FORCE_TCP:=1}" "${QUIC_MODE:=GLOBAL}" "${PORTS_TCP:=80,443}" "${QNUM:=200}" "${ENABLE_HOTSPOT:=1}" "${DNS_FORWARD_HOTSPOT:=1}" "${DNS_FORWARD_SERVER:=1.1.1.1}"
mkdir -p "$RUN_DIR"

acquire_lock() {
  local lock_attempt=0 lock_pid
  while ! mkdir "$SERVICE_LOCK" 2>/dev/null; do
    lock_pid=$(cat "$SERVICE_LOCK/pid" 2>/dev/null)
    case "$lock_pid" in
      ''|0|*[!0-9]*) rm -rf "$SERVICE_LOCK" 2>/dev/null ;;
      *)
        if ! kill -0 "$lock_pid" 2>/dev/null; then
          rm -rf "$SERVICE_LOCK" 2>/dev/null
        fi
        ;;
    esac
    lock_attempt=$((lock_attempt + 1))
    if [ "$lock_attempt" -ge 10 ]; then
      log "Пропуск перезапуска: другая перезагрузка службы уже выполняется"
      return 1
    fi
    sleep 1
  done
  echo $$ > "$SERVICE_LOCK/pid"
  return 0
}

if ! acquire_lock; then
  exit 0
fi

release_service_lock() {
  local mypid
  mypid=$(cat "$SERVICE_LOCK/pid" 2>/dev/null)
  if [ "$mypid" = "$$" ]; then
    rm -rf "$SERVICE_LOCK" 2>/dev/null
  fi
}
trap 'release_service_lock; exit 1' HUP INT TERM
trap release_service_lock EXIT

stop_pid "$NFQWS_PID_FILE" "nfqws2"
stop_owned_nfqws
cleanup_iptables
cleanup_ip_forward_bind_mount

if [ "$1" = "stop" ]; then
  stop_pid "$WATCHER_PID_FILE" "inotifyd"
  log "Служба остановлена"
  exit 0
fi

case "$STRATEGY_MODE" in
  AUTO) DESYNC_ARGS="$DESYNC_ARGS_AUTO" ;;
  *) DESYNC_ARGS="$DESYNC_ARGS_SIMPLE" ;;
esac
log "Запуск: MODE=$MODE, стратегия=$STRATEGY_MODE, QUIC_MODE=$QUIC_MODE, ENABLE_HOTSPOT=$ENABLE_HOTSPOT"

HOST_ARGS=""
[ -s "$EXCLUDE_DOMAINS_FILE" ] && HOST_ARGS="$HOST_ARGS --hostlist-exclude=$EXCLUDE_DOMAINS_FILE"
ALT_ARGS=""
if [ -s "$AUTO_DOMAINS_FILE" ] && [ -n "$DESYNC_ARGS_ALT" ]; then
  ALT_ARGS="--new --hostlist=$AUTO_DOMAINS_FILE $DESYNC_ARGS_ALT"
fi

cd "$BIN_DIR" || exit 1
if command -v nohup >/dev/null 2>&1; then
  nohup ./nfqws2 --user=root --qnum="$QNUM" --bind-fix4 --bind-fix6 \
    --lua-init="@$BIN_DIR/zapret-lib.lua" --lua-init="@$BIN_DIR/zapret-antidpi.lua" --lua-init="@$BIN_DIR/zapret-auto.lua" \
    $HOST_ARGS $DESYNC_ARGS $ALT_ARGS >> "$LOG_FILE" 2>&1 &
else
  ./nfqws2 --user=root --qnum="$QNUM" --bind-fix4 --bind-fix6 \
    --lua-init="@$BIN_DIR/zapret-lib.lua" --lua-init="@$BIN_DIR/zapret-antidpi.lua" --lua-init="@$BIN_DIR/zapret-auto.lua" \
    $HOST_ARGS $DESYNC_ARGS $ALT_ARGS >> "$LOG_FILE" 2>&1 &
fi
echo $! > "$NFQWS_PID_FILE"
sleep 1
nfqws_pid=$(cat "$NFQWS_PID_FILE" 2>/dev/null)
if ! kill -0 "$nfqws_pid" 2>/dev/null; then
  log "Ошибка запуска nfqws2: процесс завершился"
  rm -f "$NFQWS_PID_FILE"
  exit 1
fi

setup_iptables() {
  iptables -w 5 -t mangle -N ZAPRET2_MANGLE
  iptables -w 5 -t filter -N ZAPRET2_FILTER
  ip6tables -w 5 -t mangle -N ZAPRET2_MANGLE 2>/dev/null
  ip6tables -w 5 -t filter -N ZAPRET2_FILTER 2>/dev/null

  case "$MODE" in
    GLOBAL)
      iptables -w 5 -t mangle -A ZAPRET2_MANGLE -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass
      ip6tables -w 5 -t mangle -A ZAPRET2_MANGLE -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null ;;
    EXCLUDE)
      for uid in $(get_app_uids "$EXCLUDE_LIST"); do
        iptables -w 5 -t mangle -A ZAPRET2_MANGLE -m owner --uid-owner "$uid" -j RETURN
        ip6tables -w 5 -t mangle -A ZAPRET2_MANGLE -m owner --uid-owner "$uid" -j RETURN 2>/dev/null
      done
      iptables -w 5 -t mangle -A ZAPRET2_MANGLE -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass
      ip6tables -w 5 -t mangle -A ZAPRET2_MANGLE -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null ;;
    INCLUDE)
      for uid in $(get_app_uids "$APPS_LIST"); do
        iptables -w 5 -t mangle -A ZAPRET2_MANGLE -m owner --uid-owner "$uid" -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass
        ip6tables -w 5 -t mangle -A ZAPRET2_MANGLE -m owner --uid-owner "$uid" -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null
      done ;;
    *) log "Недопустимый MODE=$MODE; используется EXCLUDE" ;;
  esac
  iptables -w 5 -t mangle -A OUTPUT -j ZAPRET2_MANGLE
  ip6tables -w 5 -t mangle -A OUTPUT -j ZAPRET2_MANGLE 2>/dev/null

  if [ "$ENABLE_HOTSPOT" = "1" ]; then
    setup_ip_forward_bind_mount

    iptables -w 5 -t mangle -N ZAPRET2_MANGLE_FORWARD 2>/dev/null
    ip6tables -w 5 -t mangle -N ZAPRET2_MANGLE_FORWARD 2>/dev/null

    iptables -w 5 -t mangle -A ZAPRET2_MANGLE_FORWARD -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass
    ip6tables -w 5 -t mangle -A ZAPRET2_MANGLE_FORWARD -p tcp -m multiport --dports "$PORTS_TCP" -m mark ! --mark 0x40000000/0x40000000 -j NFQUEUE --queue-num "$QNUM" --queue-bypass 2>/dev/null

    iptables -w 5 -t mangle -A FORWARD -j ZAPRET2_MANGLE_FORWARD 2>/dev/null
    ip6tables -w 5 -t mangle -A FORWARD -j ZAPRET2_MANGLE_FORWARD 2>/dev/null

    if [ "$DNS_FORWARD_HOTSPOT" = "1" ]; then
      iptables -w 5 -t nat -N ZAPRET2_NAT_PREROUTING 2>/dev/null
      for sub in 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do
        iptables -w 5 -t nat -A ZAPRET2_NAT_PREROUTING -s "$sub" -p udp --dport 53 -j DNAT --to "${DNS_FORWARD_SERVER:-1.1.1.1}"
      done
      iptables -w 5 -t nat -A PREROUTING -j ZAPRET2_NAT_PREROUTING 2>/dev/null
    fi
  fi

  if [ "$FORCE_TCP" = "1" ]; then
    case "$QUIC_MODE" in
      GLOBAL)
        iptables -w 5 -t filter -A ZAPRET2_FILTER -p udp --dport 443 -j REJECT --reject-with icmp-port-unreachable
        ip6tables -w 5 -t filter -A ZAPRET2_FILTER -p udp --dport 443 -j REJECT --reject-with icmp-port-unreachable 2>/dev/null ;;
      SELECTED)
        for uid in $(get_app_uids "$FORCE_TCP_APPS_LIST"); do
          iptables -w 5 -t filter -A ZAPRET2_FILTER -m owner --uid-owner "$uid" -p udp -j REJECT --reject-with icmp-port-unreachable
          ip6tables -w 5 -t filter -A ZAPRET2_FILTER -m owner --uid-owner "$uid" -p udp -j REJECT --reject-with icmp-port-unreachable 2>/dev/null
        done ;;
    esac
  fi
  iptables -w 5 -t filter -A OUTPUT -j ZAPRET2_FILTER
  ip6tables -w 5 -t filter -A OUTPUT -j ZAPRET2_FILTER 2>/dev/null
}

setup_iptables

if [ "$1" != "reload" ]; then
  stop_pid "$WATCHER_PID_FILE" "inotifyd"
  WATCH_TARGETS="$CONF_FILE:w $APPS_LIST:w $EXCLUDE_LIST:w $AUTO_DOMAINS_FILE:w $EXCLUDE_DOMAINS_FILE:w $FORCE_TCP_APPS_LIST:w"

  if command -v inotifyd >/dev/null 2>&1; then
    inotifyd "$MODDIR/on_change.sh" $WATCH_TARGETS 2>/dev/null &
  elif command -v busybox >/dev/null 2>&1; then
    busybox inotifyd "$MODDIR/on_change.sh" $WATCH_TARGETS 2>/dev/null &
  else
    log "inotifyd не найден: автоматическая перезагрузка списков недоступна"
  fi
  echo $! > "$WATCHER_PID_FILE"
fi
log "Служба запущена: nfqws2 PID $(cat "$NFQWS_PID_FILE")"
