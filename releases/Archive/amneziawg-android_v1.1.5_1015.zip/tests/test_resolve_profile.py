#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тест-сьют для проверки resolve-profile, парсинга конфигураций и спецсимволов в awg-controller.
Проверяет:
1. Fallback .json vs .opts (приоритет .json, поддержка устаревших .opts, отсутствие обоих)
2. Парсинг опций (routing_mode, dns/custom_dns, killswitch, lan_bypass, trusted_wifi)
3. Имена профилей со спецсимволами (дефис, подчеркивание, точка, пробелы, кириллица)
4. Разрешение UIDs: пустые списки, множественные UIDs, пробелы, переносы строк
5. Парсинг .conf файлов (Address, DNS, MTU, ListenPort, AllowedIPs, IPv6 detection)
"""

import os
import sys
import tempfile
import subprocess
import shutil

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

BASH_PATH = r"C:\Program Files\Git\bin\bash.exe"
REPO_ROOT = r"F:\Antigravity\MagiskModuls\module\amneziawg-android"
CONTROLLER_PATH = os.path.join(REPO_ROOT, "bin", "awg-controller").replace("\\", "/")

def run_bash_snippet(snippet):
    cmd = [BASH_PATH, "-c", snippet]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return res

def test_json_opts_fallback_and_options():
    print("=== ТЕСТ 2.1: Проверка приоритета .json vs .opts и парсинга get_opt_val ===")
    test_dir = tempfile.mkdtemp(prefix="awg_opts_test_")
    try:
        profiles_dir = os.path.join(test_dir, "profiles").replace("\\", "/")
        os.makedirs(os.path.join(test_dir, "profiles"), exist_ok=True)

        # 1. Профиль только с .opts
        with open(os.path.join(test_dir, "profiles", "legacy.opts"), "w", encoding="utf-8") as f:
            f.write('{"routing_mode": "exclude_apps", "killswitch": true, "lan_bypass": false, "dns": "1.1.1.1"}')

        # 2. Профиль с .json и .opts (приоритет у .json)
        with open(os.path.join(test_dir, "profiles", "both.json"), "w", encoding="utf-8") as f:
            f.write('{\n  "routing_mode": "all_traffic",\n  "custom_dns": "8.8.8.8",\n  "killswitch": false\n}')
        with open(os.path.join(test_dir, "profiles", "both.opts"), "w", encoding="utf-8") as f:
            f.write('{"routing_mode": "include_apps", "dns": "9.9.9.9"}')

        # 3. Профиль без опций (должны вернуться дефолты)
        # no file

        snippet = f"""
PROFILES_DIR="{profiles_dir}"
eval "$(sed -n '/^get_opt_val()/,/^}}/p' "{CONTROLLER_PATH}")"

resolve_opts_file() {{
  local p="$1"
  local opts="$PROFILES_DIR/${{p}}.json"
  [ -f "$opts" ] || opts="$PROFILES_DIR/${{p}}.opts"
  printf '%s' "$opts"
}}

# Тест legacy.opts
f_legacy="$(resolve_opts_file "legacy")"
echo "legacy_file: $(basename "$f_legacy")"
echo "legacy_mode: $(get_opt_val "$f_legacy" "routing_mode" "include_apps")"
echo "legacy_kill: $(get_opt_val "$f_legacy" "killswitch" "false")"
echo "legacy_dns: $(get_opt_val "$f_legacy" "custom_dns" "")"

# Тест both (json приоритет)
f_both="$(resolve_opts_file "both")"
echo "both_file: $(basename "$f_both")"
echo "both_mode: $(get_opt_val "$f_both" "routing_mode" "include_apps")"
echo "both_dns: $(get_opt_val "$f_both" "dns" "")"

# Тест none (дефолты)
f_none="$(resolve_opts_file "none")"
echo "none_mode: $(get_opt_val "$f_none" "routing_mode" "include_apps")"
echo "none_lan: $(get_opt_val "$f_none" "lan_bypass" "true")"
"""
        res = run_bash_snippet(snippet)
        assert res.returncode == 0, f"Snippet failed: {res.stderr}"
        lines = dict(l.split(": ", 1) for l in res.stdout.strip().splitlines() if ": " in l)
        for k, v in lines.items():
            print(f"  {k} = {v}")

        assert lines["legacy_file"] == "legacy.opts"
        assert lines["legacy_mode"] == "exclude_apps"
        assert lines["legacy_kill"] == "true"
        assert lines["legacy_dns"] == "1.1.1.1"

        assert lines["both_file"] == "both.json"
        assert lines["both_mode"] == "all_traffic"
        assert lines["both_dns"] == "8.8.8.8"

        assert lines["none_mode"] == "include_apps"
        assert lines["none_lan"] == "true"

        print("РЕЗУЛЬТАТ: УСПЕШНО (fallback .json/.opts и выборка опций работают безошибочно)")
        return True
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)

def test_profile_special_names_and_uids():
    print("\n=== ТЕСТ 2.2: Имена профилей со спецсимволами и различные форматы списков UIDs ===")
    test_dir = tempfile.mkdtemp(prefix="awg_names_test_")
    try:
        profiles_dir = os.path.join(test_dir, "profiles").replace("\\", "/")
        run_dir = os.path.join(test_dir, "run").replace("\\", "/")
        os.makedirs(os.path.join(test_dir, "profiles"), exist_ok=True)
        os.makedirs(os.path.join(test_dir, "run"), exist_ok=True)

        special_profiles = [
            "wg-vpn-01",
            "vpn_work_profile.2",
            "vpn.test.server",
            "vpn home test",
            "профиль_vpn"
        ]

        # Создаем файлы для каждого профиля
        for p in special_profiles:
            conf_path = os.path.join(test_dir, "profiles", f"{p}.conf")
            json_path = os.path.join(test_dir, "profiles", f"{p}.json")
            with open(conf_path, "w", encoding="utf-8") as f:
                f.write(f"[Interface]\nPrivateKey = aaaa\nAddress = 10.0.0.2/32, fd00::2/128\nDNS = 1.1.1.1\n\n[Peer]\nPublicKey = bbbb\nEndpoint = 1.2.3.4:51820\nAllowedIPs = 0.0.0.0/0, ::/0\n")
            with open(json_path, "w", encoding="utf-8") as f:
                f.write('{\n  "enabled": true,\n  "routing_mode": "include_apps",\n  "killswitch": false,\n  "lan_bypass": true\n}\n')

        # Тест функции list-enabled, resolve-profile, get_conf_val, get_peer_val со спецсимволами
        snippet = f"""
PROFILES_DIR="{profiles_dir}"
RUN_DIR="{run_dir}"

get_peer_val() {{
  local file="$1"
  local key="$2"
  awk -v k="$key" '
    BEGIN {{ in_peer=0 }}
    /^\\[[pP][eE][eE][rR]\\]/ {{ in_peer=1; next }}
    /^\\[/ {{ in_peer=0 }}
    in_peer {{
      idx = index($0, "=")
      if (idx > 0) {{
        name = substr($0, 1, idx - 1)
        val = substr($0, idx + 1)
        gsub(/\\r/, "", name)
        gsub(/\\r/, "", val)
        gsub(/^[ \\t]+|[ \\t]+$/, "", name)
        gsub(/^[ \\t]+|[ \\t]+$/, "", val)
        if (tolower(name) == tolower(k)) {{
          print val
          exit
        }}
      }}
    }}
  ' "$file" 2>/dev/null
}}

get_conf_val() {{
  local file="$1"
  local key="$2"
  awk -v k="$key" '
    BEGIN {{ in_iface=0 }}
    /^\\[[iI][nN][tT][eE][rR][fF][aA][cC][eE]\\]/ {{ in_iface=1; next }}
    /^\\[/ {{ in_iface=0 }}
    in_iface {{
      idx = index($0, "=")
      if (idx > 0) {{
        name = substr($0, 1, idx - 1)
        val = substr($0, idx + 1)
        gsub(/\\r/, "", name)
        gsub(/\\r/, "", val)
        gsub(/^[ \\t]+|[ \\t]+$/, "", name)
        gsub(/^[ \\t]+|[ \\t]+$/, "", val)
        if (tolower(name) == tolower(k)) {{
          print val
          exit
        }}
      }}
    }}
  ' "$file" 2>/dev/null
}}

eval "$(sed -n '/^get_opt_val()/,/^}}/p' "{CONTROLLER_PATH}")"

# 1. list-enabled
for c in "$PROFILES_DIR"/*.conf; do
  [ -f "$c" ] || continue
  p="$(basename "$c" .conf)"
  opts="$PROFILES_DIR/${{p}}.json"
  [ -f "$opts" ] || opts="$PROFILES_DIR/${{p}}.opts"
  en="$(get_opt_val "$opts" "enabled" "false")"
  if [ "$en" = "true" ] || [ "$en" = "1" ]; then
    echo "ENABLED: $p"
    addr="$(get_conf_val "$c" "Address")"
    endpoint="$(get_peer_val "$c" "Endpoint")"
    echo "  Addr: $addr, Endpoint: $endpoint"
  fi
done

# 2. Тестирование разбора UID списков (пустые списки, одиночные, множественные, переносы)
test_uids() {{
  local uids="$1"
  local count=0
  for uid in $uids; do
    [ -z "$uid" ] && continue
    count=$((count + 1))
  done
  echo "UID_COUNT: $count"
}}

echo -n "Empty list: "
test_uids ""
echo -n "Single UID: "
test_uids "10001"
echo -n "Multiple space-separated: "
test_uids "10001 10002 10050"
echo -n "Newline-separated: "
test_uids "$(printf '10001\\n10002\\n10003\\n')"
echo -n "With extra whitespace: "
test_uids "  10001   10002   "
"""
        res = run_bash_snippet(snippet)
        assert res.returncode == 0, f"Snippet failed: {res.stderr}"
        for line in res.stdout.strip().splitlines():
            print(f"  {line}")

        # Проверяем, что все спец-профили распознаны
        for p in special_profiles:
            assert f"ENABLED: {p}" in res.stdout, f"ОШИБКА: Профиль '{p}' не распознан в list-enabled!"

        assert "Empty list: UID_COUNT: 0" in res.stdout
        assert "Single UID: UID_COUNT: 1" in res.stdout
        assert "Multiple space-separated: UID_COUNT: 3" in res.stdout
        assert "Newline-separated: UID_COUNT: 3" in res.stdout
        assert "With extra whitespace: UID_COUNT: 2" in res.stdout

        print("РЕЗУЛЬТАТ: УСПЕШНО (все спецсимволы в именах и форматы списков UIDs обрабатываются корректно)")
        return True
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)

if __name__ == "__main__":
    t1 = test_json_opts_fallback_and_options()
    t2 = test_profile_special_names_and_uids()
    if t1 and t2:
        print("\n=======================================================")
        print("ИТОГ: ВСЕ ТЕСТЫ resolve-profile УСПЕШНО ПРОЙДЕНЫ (2 из 2)!")
        print("=======================================================")
        sys.exit(0)
    else:
        sys.exit(1)
