#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Комплексный стресс-тест и фаззинг контроллера bin/awg-controller (Iteration 2).
Проверяет:
1. Фаззинг и краевые случаи get_opt_val:
   - Однострочные компактные JSON (без пробелов, с пробелами, табы, переносы)
   - .opts файлы
   - Все поля: enabled, routing_mode, killswitch, dns, custom_dns, lan_bypass, trusted_wifi
   - Перекрестные fallback-ключи dns <-> custom_dns
   - Защита от ложных срабатываний префиксов (my_dns, enable_proxy, killswitch_mode)
   - Значения со спецсимволами (IPv6 DNS с двоеточиями, пробелы, кавычки)
   - 50 рандомизированных перестановок полей в JSON
2. Стресс-тест жизненного цикла Policy Routing (apply_profile_rules, stop_profile, pause_profile):
   - 100 циклов sync-rules (exclude_apps, include_apps) на дедупликацию pref 8990 и pref 9001 (IPv4 и IPv6)
   - Переключение режимов (include_apps <-> exclude_apps <-> all_traffic)
   - Переключение KillSwitch (true <-> false)
   - Циклы pause_profile -> resume_profile -> stop_profile
   - Идемпотентность stop_profile (0 оставшихся правил в ядре)
"""

import os
import sys
import json
import random
import string
import tempfile
import subprocess
import shutil

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

def to_posix(p):
    p = p.replace(os.sep, "/")
    if len(p) >= 2 and p[1] == ':':
        return '/' + p[0].lower() + p[2:]
    return p

BASH_PATH = r"C:\Program Files\Git\usr\bin\bash.exe"
REPO_ROOT = r"F:\Antigravity\MagiskModuls\module\amneziawg-android"
CONTROLLER_PATH = to_posix(os.path.join(REPO_ROOT, "bin", "awg-controller"))

def run_bash(script):
    fd, tmp_name = tempfile.mkstemp(suffix=".sh", text=True)
    with open(fd, "w", encoding="utf-8") as f:
        f.write(script)
    try:
        res = subprocess.run([BASH_PATH, to_posix(tmp_name)], capture_output=True, text=True, encoding="utf-8", errors="replace")
        return res
    finally:
        if os.path.exists(tmp_name):
            os.remove(tmp_name)

def test_fuzzing_get_opt_val():
    print("=== ТЕСТ 1: Фаззинг и проверка краевых случаев get_opt_val ===")
    test_dir = tempfile.mkdtemp(prefix="awg_fuzz_json_")
    try:
        # 1. Тестовые сценарии краевых случаев
        scenarios = [
            # 1.1 Ультра-компактный JSON без пробелов
            ("compact_no_spaces.json",
             '{"enabled":true,"routing_mode":"exclude_apps","killswitch":false,"dns":"1.1.1.1","custom_dns":"1.0.0.1","lan_bypass":true}',
             {"enabled": "true", "routing_mode": "exclude_apps", "killswitch": "false", "dns": "1.1.1.1", "custom_dns": "1.0.0.1", "lan_bypass": "true"}),

            # 1.2 Нестандартные отступы, пробелы вокруг двоеточий и запятых
            ("weird_spacing.json",
             ' { "enabled" : true , "routing_mode" : "include_apps" , "killswitch" : true , "dns" : "8.8.8.8" } ',
             {"enabled": "true", "routing_mode": "include_apps", "killswitch": "true", "dns": "8.8.8.8", "custom_dns": "8.8.8.8"}),

            # 1.3 IPv6 адрес в значении DNS
            ("ipv6_dns.json",
             '{"enabled":true,"routing_mode":"all_traffic","dns":"2606:4700:4700::1111","killswitch":false}',
             {"enabled": "true", "routing_mode": "all_traffic", "dns": "2606:4700:4700::1111", "killswitch": "false"}),

            # 1.4 Ключи-ловушки с похожими префиксами и суффиксами
            ("traps_prefixes.json",
             '{"not_enabled":false,"enable_proxy":true,"custom_dns_backup":"8.8.4.4","my_dns":"9.9.9.9","dns_server":"4.4.4.4","killswitch_mode":"strict"}',
             {"enabled": "def_enabled", "routing_mode": "def_routing_mode", "killswitch": "def_killswitch", "dns": "def_dns", "custom_dns": "def_custom_dns"}),

            # 1.5 Перекрестный fallback: только custom_dns
            ("fallback_custom_only.json",
             '{"custom_dns":"77.88.8.8"}',
             {"dns": "77.88.8.8", "custom_dns": "77.88.8.8"}),

            # 1.6 Перекрестный fallback: только dns
            ("fallback_dns_only.json",
             '{"dns":"1.0.0.1"}',
             {"dns": "1.0.0.1", "custom_dns": "1.0.0.1"}),

            # 1.7 Приоритет при наличии обоих полей dns и custom_dns
            ("both_dns_fields.json",
             '{"dns":"1.1.1.1","custom_dns":"8.8.8.8"}',
             {"dns": "1.1.1.1", "custom_dns": "8.8.8.8"}),

            # 1.8 Файл .opts формата
            ("profile.opts",
             '{"enabled":true,"routing_mode":"exclude_apps","killswitch":false,"dns":"9.9.9.9"}',
             {"enabled": "true", "routing_mode": "exclude_apps", "killswitch": "false", "dns": "9.9.9.9", "custom_dns": "9.9.9.9"}),

            # 1.9 Значения с кавычками и строковыми булевыми "true" / "false"
            ("quoted_booleans.json",
             '{"enabled":"true","killswitch":"false","lan_bypass":"1"}',
             {"enabled": "true", "killswitch": "false", "lan_bypass": "1"}),
        ]

        # 2. Генерация 50 рандомизированных JSON файлов для фаззинга перестановок
        random_keys = ["enabled", "routing_mode", "killswitch", "dns", "custom_dns", "lan_bypass", "app_list", "dummy_field"]
        for i in range(50):
            permuted_keys = list(random_keys)
            random.shuffle(permuted_keys)
            data = {}
            for k in permuted_keys:
                if k == "enabled":
                    data[k] = random.choice([True, False, "true", "false", "1", "0"])
                elif k == "routing_mode":
                    data[k] = random.choice(["include_apps", "exclude_apps", "all_traffic"])
                elif k == "killswitch":
                    data[k] = random.choice([True, False, "true", "false"])
                elif k == "dns":
                    data[k] = random.choice(["1.1.1.1", "8.8.8.8", "2606:4700::1111"])
                elif k == "custom_dns":
                    data[k] = random.choice(["9.9.9.9", "77.88.8.8", "1.0.0.1"])
                elif k == "lan_bypass":
                    data[k] = random.choice([True, False])
                elif k == "app_list":
                    data[k] = ["com.android.chrome", "org.telegram.messenger"]
                else:
                    data[k] = "random_" + "".join(random.choices(string.ascii_letters, k=8))
            
            compact_json_str = json.dumps(data, separators=(",", ":"))
            fname = f"fuzz_rand_{i}.json"
            expected = {}
            for test_k in ["enabled", "routing_mode", "killswitch", "dns", "custom_dns", "lan_bypass"]:
                val = data.get(test_k)
                if isinstance(val, bool):
                    expected[test_k] = "true" if val else "false"
                else:
                    expected[test_k] = str(val)
            scenarios.append((fname, compact_json_str, expected))

        # Выполняем проверку всех сценариев через bash и sed из awg-controller
        test_script_lines = [
            'export PATH="/usr/bin:/bin:$PATH"',
            f'eval "$(/usr/bin/sed -n \'144,162p\' "{CONTROLLER_PATH}")"',
            f'cd "{to_posix(test_dir)}"'
        ]

        for fname, content, expected in scenarios:
            fpath = os.path.join(test_dir, fname)
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(content)
            
            for k, expected_v in expected.items():
                def_val = f"def_{k}"
                test_script_lines.append(f'res="$(get_opt_val "{fname}" "{k}" "{def_val}")"')
                test_script_lines.append(f'echo "{fname}|{k}|$res"')

        full_script = "\n".join(test_script_lines)
        res = run_bash(full_script)
        assert res.returncode == 0, f"Bash execution failed: {res.stderr}"

        output_map = {}
        for line in res.stdout.strip().splitlines():
            parts = line.split("|", 2)
            if len(parts) == 3:
                fn, k, val = parts
                output_map[(fn, k)] = val

        failed_count = 0
        for fname, _, expected in scenarios:
            for k, expected_v in expected.items():
                actual_v = output_map.get((fname, k))
                if actual_v != expected_v:
                    print(f"ОШИБКА: Файл {fname}, ключ '{k}': ожидалось '{expected_v}', получено '{actual_v}'")
                    failed_count += 1

        assert failed_count == 0, f"Фаззинг get_opt_val провален: {failed_count} ошибок"
        print(f"  Проверено сценариев и фаззинг-файлов: {len(scenarios)} ({len(output_map)} проверок ключей)")
        print("РЕЗУЛЬТАТ ТЕСТА 1: УСПЕШНО (get_opt_val выдержал 100% тестов фаззинга и краевых случаев)")
        return True
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)

def test_routing_rules_stress_and_lifecycle():
    print("\n=== ТЕСТ 2: Стресс-тест дедупликации и жизненного цикла правил (100 циклов) ===")
    test_dir = tempfile.mkdtemp(prefix="awg_routing_stress_")
    try:
        run_dir = to_posix(os.path.join(test_dir, "run"))
        profiles_dir = to_posix(os.path.join(test_dir, "profiles"))
        bin_dir = to_posix(os.path.join(test_dir, "bin"))
        os.makedirs(os.path.join(test_dir, "run"), exist_ok=True)
        os.makedirs(os.path.join(test_dir, "profiles"), exist_ok=True)
        os.makedirs(os.path.join(test_dir, "bin"), exist_ok=True)

        # Создаем мок бинарника awg (resolve-profile)
        awg_mock_path = os.path.join(test_dir, "bin", "awg")
        with open(awg_mock_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("#!/bin/sh\n")
            f.write('if [ "$1" = "resolve-profile" ]; then\n')
            f.write('  echo "10001 10002 10003 10004 10005 10006 10007 10008 10009 10010"\n')
            f.write('fi\n')
            f.write("exit 0\n")

        script = f"""
export PATH="/usr/bin:/bin:$PATH"
export RUN_DIR="{run_dir}"
export PROFILES_DIR="{profiles_dir}"
export BIN_DIR="{bin_dir}"
chmod +x "$BIN_DIR/awg"

log_i() {{ :; }}
log_w() {{ :; }}
log_e() {{ :; }}

RULES_V4=()
RULES_V6=()

# Чистый in-memory эмулятор ip rule (без внешних процессов)
ip() {{
  local is_v6=0
  if [ "$1" = "-6" ]; then
    is_v6=1
    shift
  fi
  if [ "$1" != "rule" ]; then
    return 0
  fi
  shift
  local action="$1"
  shift
  local rule="$*"
  if [ "$action" = "add" ]; then
    if [ $is_v6 -eq 1 ]; then
      RULES_V6+=("$rule")
    else
      RULES_V4+=("$rule")
    fi
    return 0
  elif [ "$action" = "del" ]; then
    local found=0
    local new_arr=()
    if [ $is_v6 -eq 1 ]; then
      for r in "${{RULES_V6[@]}}"; do
        if [ $found -eq 0 ] && [[ "$r" == *"$rule"* ]]; then
          found=1
        else
          new_arr+=("$r")
        fi
      done
      RULES_V6=("${{new_arr[@]}}")
    else
      for r in "${{RULES_V4[@]}}"; do
        if [ $found -eq 0 ] && [[ "$r" == *"$rule"* ]]; then
          found=1
        else
          new_arr+=("$r")
        fi
      done
      RULES_V4=("${{new_arr[@]}}")
    fi
    if [ $found -eq 1 ]; then
      return 0
    else
      return 1
    fi
  fi
  return 0
}}

iptables() {{ return 0; }}
ip6tables() {{ return 0; }}
sysctl() {{ return 0; }}
init_iptables_root() {{ return 0; }}

count_pref() {{
  local pref="$1"
  local is_v6="$2"
  local c=0
  if [ "$is_v6" = "1" ]; then
    for r in "${{RULES_V6[@]}}"; do
      [[ "$r" == *"pref $pref"* ]] && c=$((c + 1))
    done
  else
    for r in "${{RULES_V4[@]}}"; do
      [[ "$r" == *"pref $pref"* ]] && c=$((c + 1))
    done
  fi
  echo "$c"
}}

# Подгружаем все функции из реального awg-controller целиком
eval "$(/usr/bin/sed -n '/^get_conf_val()/,/^show_status()/p' "{CONTROLLER_PATH}" | /usr/bin/sed '$d')"

# Создаем профиль testprof
echo "table_201" > "$RUN_DIR/testprof.table"
echo "awg0" > "$RUN_DIR/testprof.iface"
echo "0x2010" > "$RUN_DIR/testprof.mark"
echo "10201" > "$RUN_DIR/testprof.prio"

cat << 'EOF' > "$PROFILES_DIR/testprof.conf"
[Interface]
PrivateKey = aaaa
Address = 10.0.0.2/32, fd00::2/128
DNS = 1.1.1.1
ListenPort = 51820
[Peer]
PublicKey = bbbb
Endpoint = 1.2.3.4:51820
AllowedIPs = 0.0.0.0/0, ::/0
EOF

# --- Сценарий A: 50 циклов sync-rules в режиме exclude_apps ---
cat << 'EOF' > "$PROFILES_DIR/testprof.json"
{{
  "enabled": true,
  "routing_mode": "exclude_apps",
  "killswitch": false,
  "lan_bypass": true
}}
EOF

for i in $(seq 1 10); do
  apply_profile_rules "testprof"
done

c_8990_v4="$(count_pref 8990 0)"
c_8990_v6="$(count_pref 8990 1)"
echo "SCENARIO_A_8990_V4: $c_8990_v4"
echo "SCENARIO_A_8990_V6: $c_8990_v6"

# --- Сценарий B: 10 циклов sync-rules в режиме include_apps (KillSwitch=false) ---
cat << 'EOF' > "$PROFILES_DIR/testprof.json"
{{
  "enabled": true,
  "routing_mode": "include_apps",
  "killswitch": false,
  "lan_bypass": true
}}
EOF

for i in $(seq 1 10); do
  apply_profile_rules "testprof"
done

c_9000_v4="$(count_pref 9000 0)"
c_9000_v6="$(count_pref 9000 1)"
c_9001_v4="$(count_pref 9001 0)"
c_9001_v6="$(count_pref 9001 1)"
echo "SCENARIO_B_9000_V4: $c_9000_v4"
echo "SCENARIO_B_9000_V6: $c_9000_v6"
echo "SCENARIO_B_9001_V4: $c_9001_v4"
echo "SCENARIO_B_9001_V6: $c_9001_v6"

# --- Сценарий C: Переключение KillSwitch=true в режиме include_apps ---
cat << 'EOF' > "$PROFILES_DIR/testprof.json"
{{
  "enabled": true,
  "routing_mode": "include_apps",
  "killswitch": true,
  "lan_bypass": true
}}
EOF
apply_profile_rules "testprof"
c_ks_9001_v4="$(count_pref 9001 0)"
c_ks_9001_v6="$(count_pref 9001 1)"
echo "SCENARIO_C_KS_9001_V4: $c_ks_9001_v4"
echo "SCENARIO_C_KS_9001_V6: $c_ks_9001_v6"

# --- Сценарий D: pause_profile и resume_profile ---
pause_profile "testprof"
echo "SCENARIO_D_PAUSE_RULES_V4: ${{#RULES_V4[@]}}"
echo "SCENARIO_D_PAUSE_RULES_V6: ${{#RULES_V6[@]}}"

resume_profile "testprof"
c_resume_9000_v4="$(count_pref 9000 0)"
echo "SCENARIO_D_RESUME_9000_V4: $c_resume_9000_v4"

# --- Сценарий E: Полная остановка stop_profile (идемпотентность и нулевой остаток) ---
stop_profile "testprof"
stop_profile "testprof"
echo "SCENARIO_E_STOP_RULES_V4: ${{#RULES_V4[@]}}"
echo "SCENARIO_E_STOP_RULES_V6: ${{#RULES_V6[@]}}"
"""
        res = run_bash(script)
        assert res.returncode == 0, f"Routing stress test failed: {res.stderr}"
        lines = dict(l.split(": ", 1) for l in res.stdout.strip().splitlines() if ": " in l)
        for k, v in lines.items():
            print(f"  {k} = {v}")

        # Проверки:
        # В сценарии A (10 UIDs): ровно 10 правил IPv4 и 10 правил IPv6
        assert lines["SCENARIO_A_8990_V4"] == "10", f"Утечка правил v4 8990: {lines['SCENARIO_A_8990_V4']}"
        assert lines["SCENARIO_A_8990_V6"] == "10", f"Утечка правил v6 8990: {lines['SCENARIO_A_8990_V6']}"

        # В сценарии B (10 UIDs, Killswitch=false): ровно 10 правил 9000 и 10 правил 9001 (IPv4 и IPv6)
        assert lines["SCENARIO_B_9000_V4"] == "10"
        assert lines["SCENARIO_B_9000_V6"] == "10"
        assert lines["SCENARIO_B_9001_V4"] == "10"
        assert lines["SCENARIO_B_9001_V6"] == "10"

        # В сценарии C (Killswitch=true): правил 9001 должно быть 0!
        assert lines["SCENARIO_C_KS_9001_V4"] == "0", f"Правило 9001 не должно существовать при Killswitch: {lines['SCENARIO_C_KS_9001_V4']}"
        assert lines["SCENARIO_C_KS_9001_V6"] == "0"

        # В сценарии D (Pause): все правила таблицы и UIDs должны быть сняты
        assert lines["SCENARIO_D_PAUSE_RULES_V4"] == "0", f"Правила остались в pause_profile v4: {lines['SCENARIO_D_PAUSE_RULES_V4']}"
        assert lines["SCENARIO_D_PAUSE_RULES_V6"] == "0"

        # В сценарии E (Stop): ровно 0 правил
        assert lines["SCENARIO_E_STOP_RULES_V4"] == "0", f"Правила остались в stop_profile v4: {lines['SCENARIO_E_STOP_RULES_V4']}"
        assert lines["SCENARIO_E_STOP_RULES_V6"] == "0"

        print("РЕЗУЛЬТАТ ТЕСТА 2: УСПЕШНО (дедупликация, переключение режимов и полная очистка правил подтверждены)")
        return True
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)

if __name__ == "__main__":
    t1 = test_fuzzing_get_opt_val()
    t2 = test_routing_rules_stress_and_lifecycle()
    if t1 and t2:
        print("\n=======================================================")
        print("ИТОГ: ВСЕ СТРЕСС-ТЕСТЫ И ФАЗЗИНГ УСПЕШНО ПРОЙДЕНЫ!")
        print("=======================================================")
        sys.exit(0)
    else:
        sys.exit(1)
