#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тест проверки парсинга get_opt_val для однострочных и многострочных JSON.
"""

import subprocess

BASH_PATH = r"C:\Program Files\Git\bin\bash.exe"

snippet = """
test_json='{"enabled": true, "routing_mode": "exclude_apps", "killswitch": false, "dns": "1.1.1.1"}'

echo "=== 1. Текущая реализация awg-controller ==="
for key in enabled routing_mode killswitch dns; do
  v=$(printf '%s\\n' "$test_json" | grep -E '"'"$key"'"[[:space:]]*:' 2>/dev/null | head -n 1 | sed -E 's/.*:[[:space:]]*//; s/[",]//g' | tr -d ' \\n\\t\\r')
  echo "key '$key' => '$v'"
done

echo ""
echo "=== 2. Корректная нежадная реализация sed ==="
for key in enabled routing_mode killswitch dns; do
  v=$(printf '%s\\n' "$test_json" | sed -n -E 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*"?([^",}]+)"?.*/\\1/p' | head -n 1 | tr -d ' \\n\\t\\r')
  echo "key '$key' => '$v'"
done
"""

res = subprocess.run([BASH_PATH, "-c", snippet], capture_output=True, text=True, encoding="utf-8")
print(res.stdout)
