#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тест проверки утечки правил при повторных вызовах sync-rules с последующим stop_profile.
"""

import subprocess

BASH_PATH = r"C:\Program Files\Git\bin\bash.exe"

snippet = """
RULES_FILE="test_rules_accum.txt"
: > "$RULES_FILE"

ip() {
  if [ "$1" = "rule" ]; then
    shift
    if [ "$1" = "add" ]; then
      shift
      echo "$*" >> "$RULES_FILE"
      return 0
    elif [ "$1" = "del" ]; then
      shift
      local target="$*"
      if grep -F "$target" "$RULES_FILE" >/dev/null 2>&1; then
        local first_line=$(grep -nF "$target" "$RULES_FILE" | head -n 1 | cut -d: -f1)
        sed -i "${first_line}d" "$RULES_FILE"
        return 0
      else
        return 1
      fi
    fi
  fi
  return 0
}

# 1. apply_profile_rules вызывается 5 раз (симуляция 5 циклов sync-rules)
uids="10001 10002"
for step in 1 2 3 4 5; do
  for uid in $uids; do
    ip rule add uidrange "${uid}-${uid}" table main pref 8990
  done
done

echo "Правил pref 8990 после 5 циклов sync-rules: $(grep -c 'pref 8990' "$RULES_FILE")"

# 2. Вызов stop_profile (однократный ip rule del в цикле)
for uid in $uids; do
  ip rule del uidrange "${uid}-${uid}" table main pref 8990 2>/dev/null || true
done

echo "Правил pref 8990 ОСТАЛОСЬ в ядре после stop_profile: $(grep -c 'pref 8990' "$RULES_FILE")"
cat "$RULES_FILE"
rm -f "$RULES_FILE"
"""

res = subprocess.run([BASH_PATH, "-c", snippet], capture_output=True, text=True, encoding="utf-8")
print(res.stdout)
