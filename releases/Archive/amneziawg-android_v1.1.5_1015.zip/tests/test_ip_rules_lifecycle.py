#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тест-сьют для стресс-тестирования жизненного цикла ip rule и iptables:
1. Добавление и удаление pref 8990 (exclude_apps)
2. Добавление и удаление pref 9000 и pref 9001 (include_apps)
3. Проверка накопления дубликатов правил при периодическом вызове sync-rules / apply_profile_rules
4. Проверка симметрии и полноты очистки в stop_profile, pause_profile, cleanup_all и uninstall.sh
"""

import os
import sys
import tempfile
import subprocess
import shutil

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

BASH_PATH = r"C:\Program Files\Git\bin\bash.exe"

def run_bash_snippet(snippet):
    cmd = [BASH_PATH, "-c", snippet]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return res

def test_ip_rules_simulation():
    print("=== ТЕСТ 3.1: Симуляция Policy Routing и детекция утечки/накопления ip rule ===")
    test_dir = tempfile.mkdtemp(prefix="awg_rules_test_")
    try:
        run_dir = os.path.join(test_dir, "run").replace("\\", "/")
        profiles_dir = os.path.join(test_dir, "profiles").replace("\\", "/")
        os.makedirs(os.path.join(test_dir, "run"), exist_ok=True)
        os.makedirs(os.path.join(test_dir, "profiles"), exist_ok=True)

        # Создаем мок ip rule, отслеживающий таблицу активных правил в файле
        snippet = f"""
RUN_DIR="{run_dir}"
PROFILES_DIR="{profiles_dir}"

RULES_FILE="$RUN_DIR/ip_rules.txt"
: > "$RULES_FILE"

# Полнофункциональный эмулятор ip rule
ip() {{
  if [ "$1" = "rule" ]; then
    shift
    if [ "$1" = "add" ]; then
      shift
      echo "$*" >> "$RULES_FILE"
      return 0
    elif [ "$1" = "del" ]; then
      shift
      local target="$*"
      # Ищем первое совпадение
      if grep -F "$target" "$RULES_FILE" >/dev/null 2>&1; then
        local first_line=$(grep -nF "$target" "$RULES_FILE" | head -n 1 | cut -d: -f1)
        sed -i "${{first_line}}d" "$RULES_FILE"
        return 0
      else
        return 1
      fi
    elif [ "$1" = "show" ]; then
      cat "$RULES_FILE"
      return 0
    fi
  elif [ "$1" = "-6" ] && [ "$2" = "rule" ]; then
    shift 2
    if [ "$1" = "add" ]; then
      shift
      echo "ip6: $*" >> "$RULES_FILE"
      return 0
    elif [ "$1" = "del" ]; then
      shift
      local target="ip6: $*"
      if grep -F "$target" "$RULES_FILE" >/dev/null 2>&1; then
        local first_line=$(grep -nF "$target" "$RULES_FILE" | head -n 1 | cut -d: -f1)
        sed -i "${{first_line}}d" "$RULES_FILE"
        return 0
      else
        return 1
      fi
    fi
  fi
  return 0
}}

iptables() {{ return 0; }}
ip6tables() {{ return 0; }}

# Имитируем логику apply_profile_rules из awg-controller
apply_rules_include() {{
  local prof_name="$1"
  local table_id="201"
  local fwmark="0x2010"
  local priority="10201"
  local uids="10001 10002"
  local killswitch="false"

  # Очистка из awg-controller:392
  while ip rule del table "$table_id" 2>/dev/null; do :; done
  while ip rule del fwmark "$fwmark" 2>/dev/null; do :; done

  ip rule add fwmark "$fwmark" table "$table_id" pref "$priority"

  for uid in $uids; do
    ip rule add uidrange "${{uid}}-${{uid}}" table "$table_id" pref 9000
    if [ "$killswitch" != "true" ]; then
      ip rule add uidrange "${{uid}}-${{uid}}" table main pref 9001
    fi
  done
}}

apply_rules_exclude() {{
  local prof_name="$1"
  local table_id="201"
  local fwmark="0x2010"
  local priority="10201"
  local uids="10001 10002"

  while ip rule del table "$table_id" 2>/dev/null; do :; done
  while ip rule del fwmark "$fwmark" 2>/dev/null; do :; done

  ip rule add fwmark "$fwmark" table "$table_id" pref "$priority"

  for uid in $uids; do
    ip rule add uidrange "${{uid}}-${{uid}}" table main pref 8990
  done
  ip rule add from all table "$table_id" pref 9010
}}

stop_profile_mock() {{
  local table_id="201"
  local fwmark="0x2010"
  local uids="10001 10002"

  for uid in $uids; do
    ip rule del uidrange "${{uid}}-${{uid}}" table main pref 8990 2>/dev/null || true
    ip rule del uidrange "${{uid}}-${{uid}}" table main pref 9001 2>/dev/null || true
  done

  while ip rule del fwmark "$fwmark" 2>/dev/null; do :; done
  while ip rule del table "$table_id" 2>/dev/null; do :; done
}}

pause_profile_mock() {{
  local table_id="201"
  local uids="10001 10002"

  while ip rule del table "$table_id" 2>/dev/null; do :; done
  for uid in $uids; do
    ip rule del uidrange "${{uid}}-${{uid}}" table main pref 8990 2>/dev/null || true
    ip rule del uidrange "${{uid}}-${{uid}}" table main pref 9001 2>/dev/null || true
  done
}}

echo "--- 1. Тест одиночного запуска exclude_apps и stop_profile ---"
apply_rules_exclude "prof1"
echo "Правила после start exclude_apps:"
cat "$RULES_FILE"
stop_profile_mock
echo "Правил осталось после stop_profile: $(wc -l < "$RULES_FILE")"

echo "--- 2. Тест одиночного запуска include_apps и pause_profile ---"
apply_rules_include "prof1"
echo "Правила после start include_apps:"
cat "$RULES_FILE"
pause_profile_mock
echo "Правил осталось после pause_profile: $(wc -l < "$RULES_FILE")"

echo "--- 3. Тест повторных вызовов sync-rules (стресс-тест на утечку pref 8990 / 9001) ---"
: > "$RULES_FILE"
# Симулируем 5 циклов sync-rules в режиме exclude_apps
for i in $(seq 1 5); do
  apply_rules_exclude "prof1"
done
echo "Количество правил pref 8990 после 5 вызовов sync-rules: $(grep -c 'pref 8990' "$RULES_FILE")"
echo "Всего правил в таблице:"
cat "$RULES_FILE"
"""
        res = run_bash_snippet(snippet)
        assert res.returncode == 0, f"Snippet failed: {res.stderr}"
        print(res.stdout)

        return res.stdout
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)

if __name__ == "__main__":
    test_ip_rules_simulation()
