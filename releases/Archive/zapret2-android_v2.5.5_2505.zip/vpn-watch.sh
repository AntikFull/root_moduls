#!/system/bin/sh
# inotifyd передаёт событие изменения сетевой конфигурации первым аргументом.

MODDIR=${0%/*}
"$MODDIR/vpn-routing.sh" apply
