#!/system/bin/sh
# Handler for inotifyd file change events (Zero CPU & Battery Impact)

MODDIR="${0%/*}"
LOG_FILE="/sdcard/eCubz/zapret2_debug.log"

case "$1" in
  *.tmp|*.bak|*.swp|*.pid|*.lock) exit 0 ;;
esac

LOCKFILE="$MODDIR/run/on_change.lock"
mkdir -p "$MODDIR/run" 2>/dev/null

if [ -f "$LOCKFILE" ]; then
  exit 0
fi

touch "$LOCKFILE"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] Событие inotify: Изменение ($1 $2). Автоперезагрузка..." >> "$LOG_FILE"

sleep 2
sh "$MODDIR/service.sh" reload
rm -f "$LOCKFILE" 2>/dev/null
