#!/system/bin/sh
# Маршрутизация клиентов Hotspot через таблицу активного VPN-интерфейса.

MODDIR=${0%/*}
CONF_FILE="$MODDIR/zapret2.conf"
RUN_DIR="$MODDIR/run"
LOCK_DIR="$RUN_DIR/vpn-routing.lock"
LOG_FILE="/sdcard/eCubz/zapret2_debug.log"

[ -f "$CONF_FILE" ] && . "$CONF_FILE"
: "${ENABLE_HOTSPOT:=1}" "${ENABLE_VPN_HOTSPOT:=0}" "${VPN_TUN_NAME:=tun0}"
: "${VPN_ROUTE_PREF_BASE:=11300}" "${VPN_HOTSPOT_SUBNETS:=10.0.0.0/8 172.16.0.0/12 192.168.0.0/16}"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] VPN Hotspot: $*" >> "$LOG_FILE"; }

IP_BIN=$(command -v ip 2>/dev/null)
[ -n "$IP_BIN" ] || IP_BIN=/system/bin/ip

valid_number() {
  case "$1" in ''|*[!0-9]*) return 1 ;; *) return 0 ;; esac
}

cleanup_rules() {
  offset=0
  for subnet in $VPN_HOTSPOT_SUBNETS; do
    "$IP_BIN" rule del pref $((VPN_ROUTE_PREF_BASE + offset)) 2>/dev/null
    offset=$((offset + 1))
  done
}

read_vpn_table() {
  [ -r /data/misc/net/rt_tables ] || return 1
  while read -r table_index table_name; do
    [ "$table_name" = "$VPN_TUN_NAME" ] || continue
    valid_number "$table_index" || return 1
    echo "$table_index"
    return 0
  done < /data/misc/net/rt_tables
  return 1
}

acquire_lock() {
  mkdir -p "$RUN_DIR" || return 1
  lock_attempt=0
  while ! mkdir "$LOCK_DIR" 2>/dev/null; do
    lock_pid=$(cat "$LOCK_DIR/pid" 2>/dev/null)
    if ! valid_number "$lock_pid" || ! kill -0 "$lock_pid" 2>/dev/null; then
      rm -f "$LOCK_DIR/pid" 2>/dev/null
      rmdir "$LOCK_DIR" 2>/dev/null
    fi
    lock_attempt=$((lock_attempt + 1))
    [ "$lock_attempt" -lt 5 ] || return 1
    sleep 1
  done
  echo $$ > "$LOCK_DIR/pid"
}

release_lock() {
  [ "$(cat "$LOCK_DIR/pid" 2>/dev/null)" = "$$" ] || return 0
  rm -f "$LOCK_DIR/pid" 2>/dev/null
  rmdir "$LOCK_DIR" 2>/dev/null
}

apply_rules() {
  cleanup_rules
  [ "$ENABLE_HOTSPOT" = "1" ] && [ "$ENABLE_VPN_HOTSPOT" = "1" ] || return 0
  [ -x "$IP_BIN" ] || { log "команда ip не найдена"; return 1; }

  vpn_table=$(read_vpn_table) || { log "таблица для $VPN_TUN_NAME ещё недоступна"; return 0; }
  offset=0
  for subnet in $VPN_HOTSPOT_SUBNETS; do
    "$IP_BIN" rule add pref $((VPN_ROUTE_PREF_BASE + offset)) from "$subnet" lookup "$vpn_table" 2>/dev/null || {
      log "не удалось добавить правило для $subnet в таблицу $vpn_table"
      cleanup_rules
      return 1
    }
    offset=$((offset + 1))
  done
  log "клиенты Hotspot направлены через $VPN_TUN_NAME (таблица $vpn_table)"
}

acquire_lock || exit 0
trap 'release_lock' EXIT
case "$1" in
  apply|reload|'') apply_rules ;;
  cleanup) cleanup_rules ;;
  *) exit 2 ;;
esac
