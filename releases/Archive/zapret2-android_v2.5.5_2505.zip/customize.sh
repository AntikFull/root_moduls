# Интерактивная установка Zapret2 eCubz.

set_permissions() {
  set_perm "$MODPATH/system/bin/nfqws2" 0 0 0755
  set_perm "$MODPATH/system/bin/zapret2-control" 0 0 0755
  set_perm "$MODPATH/service.sh" 0 0 0755
  set_perm "$MODPATH/action.sh" 0 0 0755
  set_perm "$MODPATH/uninstall.sh" 0 0 0755
  set_perm "$MODPATH/on_change.sh" 0 0 0755
  set_perm "$MODPATH/vpn-routing.sh" 0 0 0755
  set_perm "$MODPATH/vpn-watch.sh" 0 0 0755
}

SKIPUNZIP=1
[ -n "$TMPDIR" ] || TMPDIR=/data/local/tmp
mkdir -p "$TMPDIR"
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR/functions.sh"

volume_select() {
  default_answer="$1"
  if ! command -v getevent >/dev/null 2>&1; then
    [ "$default_answer" = yes ] && return 0
    return 1
  fi
  event=$(getevent -qlc 1 2>/dev/null)
  echo "$event" | grep -q 'KEY_VOLUMEUP.*DOWN' && return 0
  echo "$event" | grep -q 'KEY_VOLUMEDOWN.*DOWN' && return 1
  [ "$default_answer" = yes ]
}

ask_yes_no() {
  ui_print " "
  ui_print "$1"
  ui_print "Громкость [+] — ДА, громкость [-] — НЕТ"
  volume_select "$2"
}

ui_print "***************************************"
ui_print " Zapret2 eCubz — Magisk / KernelSU / APatch"
ui_print "***************************************"

CONF_TARGET="$MODPATH/zapret2.conf"
if ask_yes_no "Включить обработку Wi-Fi Hotspot и USB-модема?" yes; then
  ENABLE_HOTSPOT_VAL=1
  if ask_yes_no "Направлять клиентов раздачи через VPN телефона (tun0)?" yes; then
    ENABLE_VPN_HOTSPOT_VAL=1
  else
    ENABLE_VPN_HOTSPOT_VAL=0
  fi
  if ask_yes_no "Отключать QUIC клиентов, чтобы использовать TCP и Zapret2?" yes; then
    FORCE_TCP_HOTSPOT_VAL=1
  else
    FORCE_TCP_HOTSPOT_VAL=0
  fi
  if ask_yes_no "Перенаправлять DNS клиентов на пул Cloudflare, Google и Quad9?" yes; then
    DNS_FORWARD_HOTSPOT_VAL=1
  else
    DNS_FORWARD_HOTSPOT_VAL=0
  fi
else
  ENABLE_HOTSPOT_VAL=0
  ENABLE_VPN_HOTSPOT_VAL=0
  FORCE_TCP_HOTSPOT_VAL=0
  DNS_FORWARD_HOTSPOT_VAL=0
fi

if [ -f "$CONF_TARGET" ]; then
  sed -i "s/^ENABLE_HOTSPOT=.*/ENABLE_HOTSPOT=\"$ENABLE_HOTSPOT_VAL\"/" "$CONF_TARGET"
  sed -i "s/^ENABLE_VPN_HOTSPOT=.*/ENABLE_VPN_HOTSPOT=\"$ENABLE_VPN_HOTSPOT_VAL\"/" "$CONF_TARGET"
  sed -i "s/^FORCE_TCP_HOTSPOT=.*/FORCE_TCP_HOTSPOT=\"$FORCE_TCP_HOTSPOT_VAL\"/" "$CONF_TARGET"
  sed -i "s/^DNS_FORWARD_HOTSPOT=.*/DNS_FORWARD_HOTSPOT=\"$DNS_FORWARD_HOTSPOT_VAL\"/" "$CONF_TARGET"
fi
ui_print "Установка завершена. Настройки доступны в WebUI KernelSU Next."
