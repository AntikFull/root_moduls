#!/system/bin/sh
# Exact-state rollback for Analytics & Ads Disabler v4.4.5.
MODDIR=${0%/*}
[ -f "$MODDIR/common.sh" ] && . "$MODDIR/common.sh"

DATA_DIR="${DATA_DIR:-/data/adb/analytics_ads_disabler}"
LOG_DIR="$DATA_DIR/logs"
mkdir -p "$LOG_DIR" 2>/dev/null
LOGFILE="$LOG_DIR/uninstall.log"
echo "=== [$(date)] v4.4.9 uninstall rollback ===" > "$LOGFILE"
ensure_capability_profile >/dev/null 2>&1
load_capabilities

stop_owned_pidfile "$WATCH_PID_FILE" "config_watch.sh"
stop_owned_pidfile "$INOTIFY_PID_FILE" "on_app_installed.sh"
stop_owned_pidfile "$CONFIG_INOTIFY_PID_FILE" "config_event.sh"
stop_owned_pidfile "$DATA_DIR/category_watch.pid" "category_watch.sh"

# Restore each component exactly to the override state captured before the module first touched it.
if [ -f "$COMPONENT_STATE" ]; then
    cp "$COMPONENT_STATE" "$COMPONENT_STATE.uninstall_work" 2>/dev/null
    while IFS='|' read -r user comp original; do
        [ -z "$comp" ] && continue
        if set_component_state_smart "$user" "$comp" "${original:-default}"; then
            echo "[$(date)] RESTORED u$user $comp -> ${original:-default}" >> "$LOGFILE"
        else
            echo "[$(date)] FAILED u$user $comp -> ${original:-default}" >> "$LOGFILE"
        fi
    done < "$COMPONENT_STATE.uninstall_work"
fi

# Keep uninstall log briefly impossible once data dir is removed; module data itself should not linger.
rm -rf "$DATA_DIR"
