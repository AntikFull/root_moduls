# Analytics & Ads Disabler

[ Русский](#русский) | [ English](#english)

---

## <a name="русский"></a>  Описание (Russian)

**Analytics & Ads Disabler** — адаптивный системный модуль для Magisk / KernelSU / APatch, отключающий встроенные сервисы аналитики, телеметрии и рекламные компоненты (Services, Receivers, Providers) в установленных приложениях и прошивке Android.

### Основные возможности
-  **Runtime Adaptive Engine:** Автоматическая адаптация под версию Android и оболочку (MIUI, HyperOS, OneUI, ColorOS, Pixel и др.).
-  **Экономия заряда и ресурсов:** Отключение фоновых трекеров снижает расход батареи и оперативной памяти.
-  **Блокировка рекламы и трекинга:** Отключение рекламных ресиверов и служб сбора данных (Yandex Metrica, Google Analytics, Firebase, AppMetrica и др.).
-  **Поддержка динамического отслеживания:** Автоматически обрабатывает новые и обновляемые приложения.
-  **Белые списки:** Возможность внесения исключений в `whitelist.list`, `white_ads.list`, `white_analytics.list`.

---

## <a name="english"></a>  Description (English)

**Analytics & Ads Disabler** is an adaptive Magisk / KernelSU / APatch system module designed to disable built-in analytics, telemetry, and advertising components (Services, Receivers, Providers) across user applications and system firmware.

### Features
-  **Runtime Adaptive Engine:** Automatically adjusts behavior based on Android version and OEM ROM (MIUI, HyperOS, OneUI, ColorOS, Pixel, etc.).
-  **Battery & RAM Saver:** Disabling background telemetry services reduces idle battery drain and frees up memory.
-  **Ad & Telemetry Disabler:** Neutralizes analytics/tracking components (Google Analytics, Firebase, AppMetrica, Yandex Metrica, etc.).
-  **App Monitor:** Automatically applies disabler rules when new apps are installed or updated.
-  **Custom Whitelists:** Highly configurable via `whitelist.list`, `white_ads.list`, and `white_analytics.list`.

---

## Автор и Сообщество / Author & Community
- **Автор / Author:** eCubz ([https://t.me/eCubz](https://t.me/eCubz))
- **Telegram Чат / Support Group:** [https://t.me/module_ecubz](https://t.me/module_ecubz)

---

---

---

## Донаты и поддержка / Donations
Ваша поддержка помогает развивать и поддерживать проекты! / Your support helps keep these projects active!

- СБП: `+7 923 618-89-93`
- Т-Банк: [Перевод Т-Банк](https://www.tinkoff.ru/rm/r_qoRUrMgqrw.gQAquXjKzF/ca7Vm7131)
- Ю.Money (Яндекс): [Перевод Ю.Money](https://yoomoney.ru/to/410011494875904)
- Crypto: [USDT | GRAM (Telegram Crypto Bot)](http://t.me/send?start=IVjCT8LiszJ2)
- TON Wallet (USDT): `UQCLyovMu5882XPekfUqXOLFbYFHROaB9uoWMsIaifvMqEC4`

---

## Лицензия / License

Модуль распространяется бесплатно под лицензией MIT. При распространении сохранение авторства **eCubz** и ссылки на канал **https://t.me/module_ecubz** обязательно.


## Policy and whitelist behavior (v4.4.1)

The compatibility backend only decides **how** a PackageManager state change is executed. It never decides **what** may be changed. System protection, global whitelist, category whitelist, ADS/ANALYTICS rules, and safety limits are evaluated first.

If a package is later added to `whitelist.list`, `white_ads.list`, or `white_analytics.list`, reconciliation removes only this module's matching memberships. A component is restored only when no remaining category still requires it, and restoration uses the exact override state saved before the module first touched that component. Components not tracked by this module are never bulk-enabled.

A verified learned write transport is reused for restore operations as well as disable operations. If it fails, the module falls back through the compatibility restore cascade and verifies the resulting state.


## Realtime config watch (v4.4.1)

When `REALTIME_MONITOR=1` and BusyBox `inotifyd` is available, changes to `settings.conf`, `rules.conf`, `whitelist.list`, `white_ads.list`, and `white_analytics.list` trigger an immediate policy reconciliation. The watcher listens on the module data directory so both direct writes and atomic replace/rename saves are detected. A hash-based polling loop remains enabled as a safety net and deduplicates events under the global operation lock.


### Config file paths (v4.4.8+)
The authoritative configuration lives in `/data/adb/analytics_ads_disabler/`. For convenience, the same filenames under `/data/adb/modules/analytics_ads_disabler/` are symlinks to those persistent files, so either path is safe to edit.

### Log file paths (v4.4.9+)
All module log files (`debug.log`, `diagnostics.log`, `boot_trace.log`, `install_diagnostics.log`, `uninstall.log`) are consolidated under `/data/adb/analytics_ads_disabler/logs/`. External user-accessible copies are mirrored under `/sdcard/eCubz/logs/Analytics_Ads_Disabler/`.
