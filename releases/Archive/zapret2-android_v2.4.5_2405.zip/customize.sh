# Интерактивная установка модуля Zapret2 eCubz (Volume Keys)

set_permissions() {
  set_perm $MODPATH/system/bin/nfqws2 0 0 0755
  set_perm $MODPATH/system/bin/zapret2-control 0 0 0755
  set_perm $MODPATH/service.sh 0 0 0755
  set_perm $MODPATH/action.sh 0 0 0755
  set_perm $MODPATH/uninstall.sh 0 0 0755
  set_perm $MODPATH/on_change.sh 0 0 0755
}

SKIPUNZIP=1
[ -z "$TMPDIR" ] && TMPDIR=/data/local/tmp
mkdir -p "$TMPDIR"
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR/functions.sh"

ui_print "***********************************************"
ui_print "* Zapret2 eCubz (Magisk / KernelSU / APatch)  *"
ui_print "* Автор: eCubz (https://t.me/eCubz)            *"
ui_print "* Канал: https://t.me/module_ecubz             *"
ui_print "***********************************************"

volume_select() {
  default_answer="$1"
  if ! command -v getevent >/dev/null 2>&1; then
    ui_print "! getevent недоступен; используется выбор по умолчанию."
    [ "$default_answer" = "yes" ] && return 0
    return 1
  fi

  while true; do
    if command -v timeout >/dev/null 2>&1; then
      event="$(timeout 15 getevent -qlc 1 2>/dev/null)"
      if [ -z "$event" ]; then
        ui_print "! Таймаут нажатия; используется выбор по умолчанию."
        [ "$default_answer" = "yes" ] && return 0
        return 1
      fi
    else
      event="$(getevent -qlc 1 2>/dev/null)"
    fi
    echo "$event" | grep -q "KEY_VOLUMEUP.*DOWN" && return 0
    echo "$event" | grep -q "KEY_VOLUMEDOWN.*DOWN" && return 1
  done
}

ask_yes_no() {
  prompt="$1"
  recommended="$2"
  ui_print " "
  ui_print "$prompt"
  ui_print "  Громкость [+] = ДА    Громкость [-] = НЕТ"
  [ -n "$recommended" ] && ui_print "  Рекомендуется: $recommended"
  if volume_select "$( [ "$recommended" = "YES" ] && echo yes || echo no )"; then
    ui_print "  -> Выбрано: ДА"
    return 0
  fi
  ui_print "  -> Выбрано: НЕТ"
  return 1
}

# Опрос пользователя при установке
CONF_TARGET="$MODPATH/zapret2.conf"

if ask_yes_no "Включить обход DPI для раздаваемого интернета (Wi-Fi Hotspot / USB Tethering)?" "YES"; then
  ENABLE_HOTSPOT_VAL="1"
  if ask_yes_no "Перенаправлять DNS клиентов Hotspot на защищённый сервер (1.1.1.1)?" "YES"; then
    DNS_FORWARD_HOTSPOT_VAL="1"
  else
    DNS_FORWARD_HOTSPOT_VAL="0"
  fi
else
  ENABLE_HOTSPOT_VAL="0"
  DNS_FORWARD_HOTSPOT_VAL="0"
fi

if [ -f "$CONF_TARGET" ]; then
  sed -i "s/^ENABLE_HOTSPOT=.*/ENABLE_HOTSPOT=\"$ENABLE_HOTSPOT_VAL\"/" "$CONF_TARGET"
  sed -i "s/^DNS_FORWARD_HOTSPOT=.*/DNS_FORWARD_HOTSPOT=\"$DNS_FORWARD_HOTSPOT_VAL\"/" "$CONF_TARGET"
  ui_print "- Настройки Hotspot успешно записаны в zapret2.conf"
fi

ui_print "- Установка завершена!"
