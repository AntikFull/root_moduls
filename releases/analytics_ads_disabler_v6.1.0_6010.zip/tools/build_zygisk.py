#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Автоматический компилятор и сборщик нативного движка AAD (Zygisk + DEX).
Собирает:
 1. ecubz.analytics.disabler.zygisk.AadCore (Java) -> aad_core.dex
 2. zygisk_aad (Android NDK C++ Clang) -> arm64-v8a.so, armeabi-v7a.so, x86.so, x86_64.so
 3. Автоматически вычисляет SHA-256 и генерирует integrity.manifest
 4. Синхронизирует SHA-256 в qa_targets.list
Автор: eCubz (https://t.me/eCubz)
"""

import os
import sys
import subprocess
import shutil
import hashlib

ROOT_DIR = r"F:\Antigravity\MagiskModuls"
SRC_JAVA = os.path.join(ROOT_DIR, r"module\zygisk_aad\src\ecubz\analytics\disabler\zygisk\AadCore.java")
SRC_CPP = os.path.join(ROOT_DIR, r"module\zygisk_aad\jni\main.cpp")
MODULE_DIR = os.path.join(ROOT_DIR, r"module\analytics_ads_disabler")
OUT_ZYGISK = os.path.join(MODULE_DIR, "zygisk")
TEMP_DIR = os.path.join(ROOT_DIR, r"TEMP\zygisk_build")

JAVA_HOME = r"C:\Program Files\Java\jdk-25.0.2"
JAVAC = os.path.join(JAVA_HOME, "bin", "javac.exe")
D8 = r"C:\Users\DimaPC\AppData\Local\Android\Sdk\build-tools\35.0.0\d8.bat"
ANDROID_JAR = r"C:\Users\DimaPC\AppData\Local\Android\Sdk\platforms\android-35\android.jar"
NDK_BIN = r"C:\Users\DimaPC\AppData\Local\Android\Sdk\ndk\27.0.12077973\toolchains\llvm\prebuilt\windows-x86_64\bin"

os.environ["JAVA_HOME"] = JAVA_HOME
os.environ["PATH"] = os.path.join(JAVA_HOME, "bin") + os.pathsep + os.environ.get("PATH", "")

os.makedirs(OUT_ZYGISK, exist_ok=True)
if os.path.isdir(TEMP_DIR):
    shutil.rmtree(TEMP_DIR)
os.makedirs(TEMP_DIR, exist_ok=True)

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest().lower()

print("=" * 60)
print(" Сборщик нативного Zygisk-движка AAD (Android NDK Clang)")
print(" Автор: eCubz (https://t.me/eCubz)")
print("=" * 60)

# 1. Компиляция Java -> DEX
print("[1/3] Компиляция байт-кода AadCore.java -> aad_core.dex...")
classes_dir = os.path.join(TEMP_DIR, "classes")
os.makedirs(classes_dir, exist_ok=True)

javac_cmd = [
    JAVAC,
    "-encoding", "UTF-8",
    "-source", "1.8",
    "-target", "1.8",
    "-cp", ANDROID_JAR,
    "-d", classes_dir,
    SRC_JAVA
]
res = subprocess.run(javac_cmd, capture_output=True, text=True)
if res.returncode != 0:
    print(f"[ERROR] javac failed: {res.stderr}")
    sys.exit(1)

dex_out_dir = os.path.join(TEMP_DIR, "dex")
os.makedirs(dex_out_dir, exist_ok=True)

class_files = []
for root, dirs, files in os.walk(classes_dir):
    for f in files:
        if f.endswith(".class"):
            class_files.append(os.path.join(root, f))

d8_cmd = [D8, "--output", dex_out_dir, "--min-api", "26"] + class_files
res = subprocess.run(d8_cmd, capture_output=True, text=True, shell=True)
if res.returncode != 0:
    print(f"[ERROR] d8 failed: {res.stderr}")
    sys.exit(1)

dex_src = os.path.join(dex_out_dir, "classes.dex")
dex_dst = os.path.join(OUT_ZYGISK, "aad_core.dex")
shutil.copyfile(dex_src, dex_dst)
dex_hash = file_sha256(dex_dst)
print(f"[OK] aad_core.dex создан ({os.path.getsize(dex_dst)} байт, SHA-256: {dex_hash})")

# 2. Сборка нативных библиотек через Android NDK Clang
print("[2/3] Компиляция нативных библиотек NDK Clang (.so)...")
targets = [
    ("aarch64-linux-android26-clang++.cmd", "arm64-v8a.so"),
    ("armv7a-linux-androideabi26-clang++.cmd", "armeabi-v7a.so"),
    ("x86_64-linux-android26-clang++.cmd", "x86_64.so"),
    ("i686-linux-android26-clang++.cmd", "x86.so"),
]

so_hashes = {}
for compiler_name, so_name in targets:
    compiler = os.path.join(NDK_BIN, compiler_name)
    so_dst = os.path.join(OUT_ZYGISK, so_name)
    cmd = [
        compiler,
        "-shared",
        "-fPIC",
        "-O3",
        "-static-libstdc++",
        "-std=c++20",
        "-fno-threadsafe-statics",
        "-fno-rtti",
        "-fno-exceptions",
        "-fvisibility=hidden",
        "-fvisibility-inlines-hidden",
        "-Wl,-Bsymbolic",
        "-Wl,--no-rosegment",
        "-Wl,-z,max-page-size=16384",
        "-Wl,-z,common-page-size=16384",
        "-llog",
        "-ldl",
        f"-Wl,-soname,{so_name}",
        SRC_CPP,
        "-o", so_dst
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, shell=True)
    if res.returncode != 0:
        print(f"[ERROR] Сборка {so_name} завершилась с ошибкой:")
        print(res.stderr)
        sys.exit(1)
    h = file_sha256(so_dst)
    so_hashes[so_name] = h
    print(f"[OK] {so_name} успешно собран ({os.path.getsize(so_dst)} байт, SHA-256: {h})")

# 3. Генерация integrity.manifest и синхронизация qa_targets.list
print("[3/3] Генерация integrity.manifest и обновление qa_targets.list...")
manifest_file = os.path.join(MODULE_DIR, "integrity.manifest")
with open(manifest_file, "w", encoding="utf-8", newline="\n") as f:
    f.write("# Analytics & Ads Disabler Integrity Manifest\n")
    f.write(f"zygisk/aad_core.dex={dex_hash}\n")
    for so_name, h in so_hashes.items():
        f.write(f"zygisk/{so_name}={h}\n")
print(f"[OK] integrity.manifest сгенерирован: {manifest_file}")

qa_file = os.path.join(MODULE_DIR, "qa_targets.list")
with open(qa_file, "w", encoding="utf-8", newline="\n") as f:
    f.write("# Формат: PACKAGE_OR_PROCESS|CURRENT_SIGNER_SHA256|AAD_CORE_DEX_SHA256\n")
    f.write("# Все digest: 64 hex-символа без двоеточий. Legacy-строки только с именем пакета отклоняются.\n")
    f.write("# Указывать только собственные QA/debug-приложения. Пустой список отключает in-process engine.\n")
    f.write(f"# Текущий SHA-256 aad_core.dex: {dex_hash}\n")
    f.write(f"# com.example.game.qa|0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef|{dex_hash}\n")
print(f"[OK] qa_targets.list синхронизирован с актуальным SHA-256 aad_core.dex")

print("=" * 60)
print(" Сборка Zygisk и генерация манифестов целостности завершена успешно!")
print("=" * 60)
